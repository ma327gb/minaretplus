MinaretPlus - tester package
============================

Put the compiled MinaretPlus.exe in THIS folder, next to these files,
then zip the whole folder and send it.

Files in the package:
  MinaretPlus.exe   (compiled by you in VB6: File > Make MinaretPlus.exe)
  gazette2.txt      places list + program settings (the program reads
                    and updates this file - keep it beside the exe)
  minaret.chm       help file (Help menu)
  minaret2.ini      backup of the places/settings file; the program
                    uses it to recreate gazette2.txt if that is deleted

On the tester's Windows:
  - The VB6 run-time (MSVBVM60.DLL) must be installed - it already is
    on most machines that have had VB6-era software.
  - COMDLG32.OCX must be present and registered (used by the File
    Open/Save dialogs). On a machine with VB6 installed this is
    automatic. If the program reports a missing COMDLG32.OCX,
    that file must be installed/registered first.
  - Everything runs from this one folder; nothing is installed
    elsewhere, and the program writes only to gazette2.txt.

Checking notes:
  - Moon menu > "Moon (MoonCalc engine)..." opens the Moon window
    full screen; prayer schedules are under the File/Options menus
    as before. Default crescent criterion is Yallop (Options >
    Additional Info in the program, and the Moon window follows it).
